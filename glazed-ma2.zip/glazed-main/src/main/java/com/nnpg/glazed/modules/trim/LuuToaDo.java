package com.nnpg.glazed.modules.trim;

import com.nnpg.glazed.GlazedAddon;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.meteorclient.events.world.TickEvent;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class LuuToaDo extends Module {

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<String> webhook = sgGeneral.add(
        new StringSetting.Builder()
            .name("webhook-url")
            .description("Discord webhook URL.")
            .defaultValue("")
            .build()
    );

    private final Setting<String> message = sgGeneral.add(
        new StringSetting.Builder()
            .name("message")
            .description("Webhook message.")
            .defaultValue("Đã lưu tọa độ!")
            .build()
    );

    private boolean sent = false;


    public LuuToaDo() {
    super(
        GlazedAddon.trim,
        "luu-toa-do",
        "Đã gửi tọa độ về discord."
    );
}


    @Override
    public void onActivate() {
        sent = false;
    }


    @EventHandler
    private void onTick(TickEvent.Post event) {

        if (mc.player == null || sent) return;

        double x = mc.player.getX();
        double y = mc.player.getY();
        double z = mc.player.getZ();


        String content =
            message.get()
            + "\nPlayer: "
            + mc.player.getName().getString()
            + "\nX: " + (int)x
            + "\nY: " + (int)y
            + "\nZ: " + (int)z;


        sendWebhook(content);

        sent = true;
        toggle();
    }


    private void sendWebhook(String text) {

        try {

            URL url = new URL(webhook.get());

            HttpURLConnection connection =
                (HttpURLConnection) url.openConnection();

            connection.setRequestMethod("POST");
            connection.setRequestProperty(
                "Content-Type",
                "application/json"
            );

            connection.setDoOutput(true);


            String json =
                "{\"content\":\""
                + text.replace("\"", "\\\"")
                + "\"}";


            OutputStream os = connection.getOutputStream();

            os.write(json.getBytes());

            os.flush();
            os.close();


            connection.getResponseCode();

        } catch (Exception e) {

            error("Webhook error: " + e.getMessage());

        }
    }
}