package com.nnpg.glazed.modules.esp; // ← đổi package cho phù hợp với addon của bạn

import meteordevelopment.meteorclient.events.render.Render2DEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;

public class FakeScoreboard extends Module {
    // ---- Settings ----
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<String> titleSetting = sgGeneral.add(new StringSetting.Builder()
        .name("title")
        .description("Tiêu đề bảng điểm.")
        .defaultValue("Anbatukang")
        .build()
    );

    private final Setting<String> money = sgGeneral.add(new StringSetting.Builder()
        .name("money")
        .description("Số tiền hiển thị.")
        .defaultValue("6b")
        .build()
    );

    private final Setting<String> shards = sgGeneral.add(new StringSetting.Builder()
        .name("shards")
        .description("Số shards hiển thị.")
        .defaultValue("2.3K")
        .build()
    );

    private final Setting<String> kills = sgGeneral.add(new StringSetting.Builder()
        .name("kills")
        .description("Số kill hiển thị.")
        .defaultValue("503")
        .build()
    );

    private final Setting<String> deaths = sgGeneral.add(new StringSetting.Builder()
        .name("deaths")
        .description("Số death hiển thị.")
        .defaultValue("421")
        .build()
    );

    private final Setting<String> playtime = sgGeneral.add(new StringSetting.Builder()
        .name("playtime")
        .description("Thời gian chơi hiển thị.")
        .defaultValue("22d 19h")
        .build()
    );

    private final Setting<String> team = sgGeneral.add(new StringSetting.Builder()
        .name("team")
        .description("Tên team hiển thị.")
        .defaultValue("Anbatukang")
        .build()
    );

    private final Setting<String> footer = sgGeneral.add(new StringSetting.Builder()
        .name("footer")
        .description("Chân trang (có thể chứa region).")
        .defaultValue(" anbatocom")
        .build()
    );

    private final Setting<Integer> keyAllInitialSeconds = sgGeneral.add(new IntSetting.Builder()
        .name("keyall-initial-seconds")
        .description("Số giây ban đầu cho bộ đếm KeyAll.")
        .defaultValue(3599)
        .min(1)
        .sliderRange(1, 10000)
        .build()
    );

    // ---- Biến trạng thái ----
    private long keyallStartTime = 0L;
    private long keyallInitialTime = 3599L;
    private long lastMsUpdate = 0L;
    private int displayMs = 0;
    private int msChangeDirection = 1;

    public FakeScoreboard() {
        super(Modules.get().getCategory("Render"), "fake-scoreboard", "Hiển thị bảng điểm giả.");
    }

    @Override
    public void onActivate() {
        keyallStartTime = System.currentTimeMillis();
        keyallInitialTime = keyAllInitialSeconds.get();
        lastMsUpdate = System.currentTimeMillis();
        displayMs = 50 + (int)(Math.random() * 50);
        msChangeDirection = Math.random() < 0.5 ? 1 : -1;
    }

    @EventHandler
    private void onRender2D(Render2DEvent event) {
        if (mc.player == null || mc.world == null) return;

        DrawContext context = event.drawContext;
        int screenWidth = mc.getWindow().getScaledWidth();
        int screenHeight = mc.getWindow().getScaledHeight();
        int x = screenWidth - 5;
        int y = screenHeight / 2 - 50;
        renderScoreboard(context, x, y);
    }

    private void renderScoreboard(DrawContext context, int x, int y) {
        List<Text> lines = generateScoreboardLines();
        int maxWidth = 0;
        for (Text line : lines) {
            int width = mc.textRenderer.getWidth(line);
            if (width > maxWidth) maxWidth = width;
        }
        maxWidth += 4; // padding

        int currentY = y;
        for (int i = 0; i < lines.size(); i++) {
            Text line = lines.get(i);
            int lineWidth = mc.textRenderer.getWidth(line);
            int bgX = x - maxWidth;

            // Màu nền: dòng đầu và cuối trong suốt hơn
            int bgColor = (i == 0 || i == lines.size() - 1) ? 0x50000000 : 0x40000000;
            context.fill(bgX, currentY, x, currentY + 10, bgColor);

            // Căn giữa tiêu đề, căn trái các dòng khác
            int textX = (i == 0) ? bgX + (maxWidth - lineWidth) / 2 : bgX + 2;
            context.drawText(mc.textRenderer, line, textX, currentY + 1, 0xFFFFFF, false);

            currentY += 10;
        }
    }

    private List<Text> generateScoreboardLines() {
        List<Text> lines = new ArrayList<>();

        // Tiêu đề - màu vàng
        lines.add(Text.literal(titleSetting.get()).styled(style -> style.withColor(Formatting.YELLOW)));

        // Dòng trống
        lines.add(Text.literal(" "));

        // $ Money
        lines.add(Text.literal("$ ")
            .append(colored(" Money: ", 0xFFFFFF))
            .append(colored(money.get(), 0x00FF00)));

        // ★ Shards
        lines.add(Text.literal("★ ")
            .append(colored(" Shards: ", 0xFFFFFF))
            .append(colored(shards.get(), 0xA50F5C))); // 10814460 = 0xA50F5C

        // ⚔ Kills
        lines.add(Text.literal("⚔ ")
            .append(colored(" Kills: ", 0xFFFFFF))
            .append(colored(kills.get(), 0xFF0000)));

        // ☠ Deaths
        lines.add(Text.literal("☠ ")
            .append(colored(" Deaths: ", 0xFFFFFF))
            .append(colored(deaths.get(), 0xFC6A03))); // 16545539 ≈ 0xFC6A03

        // ⌛ Keyall (tự động đếm ngược)
        lines.add(Text.literal("⌛ ")
            .append(colored(" Keyall: ", 0xFFFFFF))
            .append(colored(getKeyallTimer(), 0xFFFF00)));

        // ⌚ Playtime
        lines.add(Text.literal("⌚ ")
            .append(colored(" Playtime: ", 0xFFFFFF))
            .append(colored(playtime.get(), 0xFFC800))); // 16770560 = 0xFFC800

        // 🪓 Team
        lines.add(Text.literal("🪓 ")
            .append(colored(" Team: ", 0xFFFFFF))
            .append(colored(team.get(), 0xFFFF00)));

        // Dòng trống
        lines.add(Text.literal(" "));

        // Footer (có ms thay đổi)
        lines.add(getFooterWithMs());

        return lines;
    }

    // ---- Helper: tạo Text có màu RGB ----
    private Text colored(String text, int rgb) {
        return Text.literal(text).styled(style -> style.withColor(TextColor.fromRgb(rgb)));
    }

    // ---- Bộ đếm KeyAll ----
    private String getKeyallTimer() {
        long elapsed = System.currentTimeMillis() - keyallStartTime;
        long elapsedSeconds = elapsed / 1000L;
        long remainingSeconds = Math.max(0L, keyallInitialTime - elapsedSeconds);
        long minutes = remainingSeconds / 60L;
        long seconds = remainingSeconds % 60L;
        return String.format("%dm %ds", minutes, seconds);
    }

    // ---- Footer với ms thay đổi ----
    private Text getFooterWithMs() {
        long currentTime = System.currentTimeMillis();

        // Cập nhật ms mỗi 2-4 giây (random)
        if (currentTime - lastMsUpdate > 2000L + (long)(Math.random() * 2000)) {
            int change = 1 + (int)(Math.random() * 5);
            displayMs += msChangeDirection * change;

            // Giới hạn displayMs trong khoảng 20-150
            if (displayMs < 20) {
                displayMs = 20;
                msChangeDirection = 1;
            } else if (displayMs > 150) {
                displayMs = 150;
                msChangeDirection = -1;
            }

            // 10% đổi hướng
            if (Math.random() < 0.1) {
                msChangeDirection *= -1;
            }

            lastMsUpdate = currentTime;
        }

        String raw = footer.get();
        // Tách region nếu có dấu ngoặc đơn
        int start = raw.indexOf('(');
        int end = raw.indexOf(')');
        if (start != -1 && end != -1 && end > start) {
            String region = raw.substring(0, start).trim();
            return Text.literal(region + "(" + displayMs + "ms)");
        } else {
            return Text.literal(raw + " (" + displayMs + "ms)");
        }
    }
}