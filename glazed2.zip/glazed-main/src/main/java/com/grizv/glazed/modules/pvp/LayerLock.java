package com.grizv.glazed.modules.pvp;

import com.grizv.glazed.GlazedAddon;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;

public class LayerLock extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> notifications = sgGeneral.add(new BoolSetting.Builder()
        .name("notifications")
        .description("Show notifications when placement is blocked.")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> yStart = sgGeneral.add(new IntSetting.Builder()
        .name("y-start")
        .description("Minimum Y level to allow placement.")
        .defaultValue(0)
        .min(0)
        .max(255)
        .build()
    );

    private final Setting<Integer> yEnd = sgGeneral.add(new IntSetting.Builder()
        .name("y-end")
        .description("Maximum Y level to allow placement.")
        .defaultValue(255)
        .min(0)
        .max(255)
        .build()
    );

    public LayerLock() {
        super(GlazedAddon.pvp, "layer-lock", "Blocks block placement outside a configured Y range");
    }

    public boolean isLocked() {
        return true;
    }

    public int getLockedYStart() {
        return yStart.get();
    }

    public int getLockedYEnd() {
        return yEnd.get();
    }

    public boolean isBlockAllowed(BlockItem blockItem) {
        return true;
    }

    public boolean showNotifications() {
        return notifications.get();
    }
}
