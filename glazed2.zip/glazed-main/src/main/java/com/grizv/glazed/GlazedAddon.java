package com.grizv.glazed;

import com.grizv.glazed.commands.*;
import com.grizv.glazed.MyScreen;
import com.grizv.glazed.modules.trim.*;
import com.grizv.glazed.modules.pvp.*;
import com.grizv.glazed.protection.ModRegistry;
import com.grizv.glazed.protection.TranslationProtectionHandler;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.commands.Commands;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.meteorclient.events.game.GameJoinedEvent;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import net.minecraft.item.Items;
import net.minecraft.item.ItemStack;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class GlazedAddon extends MeteorAddon {
    private static final Logger LOGGER = LoggerFactory.getLogger("Glazed");

    public static final Category CATEGORY = new Category("Glazed", new ItemStack(Items.CAKE));
    public static final Category esp = new Category("Trim ESP ", new ItemStack(Items.VINE));
    public static final Category pvp = new Category("Trim PVP", new ItemStack(Items.DIAMOND_SWORD));
    // Tạo thêm Category Trim ở đây:
    public static final Category trim = new Category("Trim", new ItemStack(Items.ARMOR_STAND));

    public static int MyScreenVERSION = 16;

    @Override
    public void onInitialize() {
        LOGGER.debug("[Glazed] Initializing protection modules");
        
        Modules.get().add(new AntiTrap());
        Modules.get().add(new CrystalMacro());
        Modules.get().add(new CrystalTweaks());
        Modules.get().add(new LayerLock());
        Modules.get().add(new AnchorMacro());
        Modules.get().add(new AutoInvTotem());
        Modules.get().add(new AutoTotem());
        Modules.get().add(new ShieldBreaker());
        Modules.get().add(new FastXP());
        Modules.get().add(new LuuToaDo());
        Modules.get().add(new FakeScoreboard());
        // Commands
        Commands.add(new SellHotbarCommand());
        Commands.add(new AHItemCommand());
        Commands.add(new OrderItemCommand());
    }
    
    @EventHandler
    private void onGameJoined(GameJoinedEvent event) {
        MyScreen.checkVersionOnServerJoin();
    }

    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        MyScreen.resetSessionCheck();
        // Clear protection caches on disconnect
        TranslationProtectionHandler.clearCache();
        ModRegistry.clearServerPackKeys();
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
        Modules.registerCategory(esp);
        Modules.registerCategory(pvp);
        // Đăng ký Category Trim vào Meteor Client:
        Modules.registerCategory(trim);
    }

    @Override
    public String getPackage() {
        return "com.grizv.glazed";
    }
}
