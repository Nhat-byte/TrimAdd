package com.grizv.glazed.modules.pvp;

import com.grizv.glazed.GlazedAddon;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;

public class CrystalTweaks extends Module {
    public CrystalTweaks() {
        super(GlazedAddon.pvp, "crystal-tweaks", "Adds compatibility hooks for crystal interaction tweaks");
    }

    public boolean shouldBlockSlotClick(int syncId, int slot, int button, SlotActionType actionType) {
        return false;
    }

    public boolean shouldBlockInteractBlock(ClientPlayerEntity player, Hand hand, BlockHitResult hitResult) {
        return false;
    }
}
