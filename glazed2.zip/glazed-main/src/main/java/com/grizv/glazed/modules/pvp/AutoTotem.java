package com.grizv.glazed.modules.pvp;

import com.grizv.glazed.GlazedAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("delay")
        .description("Ticks to wait between totem checks")
        .defaultValue(1)
        .min(1)
        .max(20)
        .sliderMin(1)
        .sliderMax(20)
        .build()
    );

    private final Setting<Boolean> moveFromHotbar = sgGeneral.add(new BoolSetting.Builder()
        .name("move-from-hotbar")
        .description("Also pull a totem from hotbar slots if needed")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> disableLogs = sgGeneral.add(new BoolSetting.Builder()
        .name("disable-logs")
        .description("Disable chat messages about totem movement")
        .defaultValue(true)
        .build()
    );

    private int delayTicks = 0;

    public AutoTotem() {
        super(GlazedAddon.pvp, "auto-totem", "Automatically moves a totem into the offhand when one is available.");
    }

    @Override
    public void onActivate() {
        delayTicks = 0;
    }

    @Override
    public void onDeactivate() {
        delayTicks = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null || mc.currentScreen != null) return;

        if (delayTicks > 0) {
            delayTicks--;
            return;
        }

        if (hasTotemInOffhand()) return;

        int totemSlot = findTotemSlot();
        if (totemSlot == -1) return;

        if (moveTotemToOffhand(totemSlot)) {
            delayTicks = delay.get();
        }
    }

    private boolean moveTotemToOffhand(int totemSlot) {
        try {
            int containerSlot = totemSlot;
            if (totemSlot < 9) {
                containerSlot = totemSlot + 36;
            }

            ItemStack offhandStack = mc.player.getOffHandStack();

            if (offhandStack.isEmpty()) {
                mc.interactionManager.clickSlot(0, containerSlot, 40, SlotActionType.SWAP, mc.player);
            } else {
                mc.interactionManager.clickSlot(0, containerSlot, 0, SlotActionType.PICKUP, mc.player);
                mc.interactionManager.clickSlot(0, 45, 0, SlotActionType.PICKUP, mc.player);
                mc.interactionManager.clickSlot(0, containerSlot, 0, SlotActionType.PICKUP, mc.player);
            }

            if (!disableLogs.get()) {
                info("Moved a totem to the offhand.");
            }
            return true;
        } catch (Exception e) {
            if (!disableLogs.get()) {
                error("Failed to move totem: " + e.getMessage());
            }
            return false;
        }
    }

    private int findTotemSlot() {
        for (int i = 9; i < 36; i++) {
            if (mc.player.getInventory().getStack(i).getItem() == Items.TOTEM_OF_UNDYING) {
                return i;
            }
        }

        if (moveFromHotbar.get()) {
            for (int i = 0; i < 9; i++) {
                if (mc.player.getInventory().getStack(i).getItem() == Items.TOTEM_OF_UNDYING) {
                    return i;
                }
            }
        }

        return -1;
    }

    private boolean hasTotemInOffhand() {
        if (mc.player == null) return false;
        ItemStack offhandStack = mc.player.getOffHandStack();
        return !offhandStack.isEmpty() && offhandStack.getItem() == Items.TOTEM_OF_UNDYING;
    }
}
