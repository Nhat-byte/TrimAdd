package com.grizv.glazed.modules.trim;

import com.google.gson.JsonObject;
import com.grizv.glazed.GlazedAddon;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.meteorclient.events.world.TickEvent;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
public class LuuToaDo extends Module{
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final Setting<String> webhook = sgGeneral.add(new StringSetting.Builder().name("webhook-url").description("Discord webhook URL.").defaultValue("").build());
    private final Setting<String> message = sgGeneral.add(new StringSetting.Builder().name("message").description("Webhook message.").defaultValue("Đã lưu tọa độ!").build());
    private boolean sent = false;
    public LuuToaDo(){ super(GlazedAddon.trim,"luu-toa-do","Đã gửi tọa độ về discord."); }
    @Override public void onActivate(){ sent = false; }
    @EventHandler private void onTick(TickEvent.Post event){
        if(mc.player==null||sent) return;
        double x=mc.player.getX(), y=mc.player.getY(), z=mc.player.getZ();
        String content = message.get()+"\nPlayer: "+mc.player.getName().getString()+"\nX: "+(int)x+"\nY: "+(int)y+"\nZ: "+(int)z;
        sendWebhook(content); sent=true; toggle();
    }
    private void sendWebhook(String text){
        String webhookUrl = webhook.get();
        if(webhookUrl==null||webhookUrl.isBlank()){ error("Webhook URL is empty. Fill the webhook-url setting first."); return; }
        try{
            URL url=new URL(webhookUrl);
            HttpURLConnection connection=(HttpURLConnection)url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type","application/json");
            connection.setRequestProperty("Accept","application/json");
            connection.setRequestProperty("User-Agent","TrimAdd/1.0");
            connection.setConnectTimeout(10000); connection.setReadTimeout(10000); connection.setDoOutput(true);
            JsonObject payload=new JsonObject(); payload.addProperty("content",text);
            byte[] bytes=payload.toString().getBytes(StandardCharsets.UTF_8);
            connection.setRequestProperty("Content-Length",Integer.toString(bytes.length));
            try(OutputStream os=connection.getOutputStream()){ os.write(bytes); os.flush(); }
            int responseCode=connection.getResponseCode(); if(responseCode>=400) error("Webhook error: HTTP "+responseCode);
            connection.disconnect();
        }catch(Exception e){ error("Webhook error: "+e.getMessage()); }
    }
}